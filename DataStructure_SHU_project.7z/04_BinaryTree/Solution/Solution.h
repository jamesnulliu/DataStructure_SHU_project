#pragma once
#include <cstdlib>
void Q_01_refresh();
void Q_01_solve();
void Q_02_refresh();
void Q_02_solve();
