#pragma once
#include <iostream>
void circle_test1(int N, const int k, const int m, std::ostream* out = &std::cout);
void circle_test2(int N, const int k, const int m, std::ostream* out = &std::cout);
