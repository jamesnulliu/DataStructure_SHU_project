#pragma once
#include <iostream>
void array_test1(int N, const int k, const int m, std::ostream* out = &std::cout);
int array_test2(int N, const int k, const int m, std::ostream* out = &std::cout);
void outputResultofTest2(int N = 100);
