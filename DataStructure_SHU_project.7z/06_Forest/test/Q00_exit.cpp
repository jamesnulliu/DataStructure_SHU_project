#include "Solution.h"

S00 S00::_solution;