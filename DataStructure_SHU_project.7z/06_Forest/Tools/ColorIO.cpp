#include "ColorIO.hpp"

namespace sgc {
    ostream ostream::_cout;
    istream istream::_cin;
}